#include "PluginProcessor.h"
#include "PluginEditor.h"

MSCVoxAudioProcessor::MSCVoxAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "MSCVOX_STATE", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout MSCVoxAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back(std::make_unique<juce::AudioParameterFloat>("input", "Input", -24.0f, 24.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("drive", "Drive", 0.0f, 100.0f, 20.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("output", "Output", -24.0f, 12.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));
    return { p.begin(), p.end() };
}

void MSCVoxAudioProcessor::prepareToPlay(double, int) {}

bool MSCVoxAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return (in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo())
        && in == out;
}

void MSCVoxAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    if (*parameters.getRawParameterValue("bypass") > 0.5f) return;

    const float inGain = juce::Decibels::decibelsToGain(parameters.getRawParameterValue("input")->load());
    const float outGain = juce::Decibels::decibelsToGain(parameters.getRawParameterValue("output")->load());
    const float drive = parameters.getRawParameterValue("drive")->load() / 100.0f;
    const float amount = 1.0f + drive * 18.0f;
    const int channels = getTotalNumOutputChannels();

    for (int ch = 0; ch < channels; ++ch)
    {
        auto* data = buffer.getWritePointer(ch);
        for (int i = 0; i < buffer.getNumSamples(); ++i)
        {
            const float x = data[i] * inGain;
            const float shaped = std::tanh(x * amount) / std::tanh(amount);
            data[i] = (x * (1.0f - drive) + shaped * drive) * outGain;
        }
    }
}

juce::AudioProcessorEditor* MSCVoxAudioProcessor::createEditor()
{
    return new MSCVoxAudioProcessorEditor(*this);
}

void MSCVoxAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}

void MSCVoxAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MSCVoxAudioProcessor();
}
