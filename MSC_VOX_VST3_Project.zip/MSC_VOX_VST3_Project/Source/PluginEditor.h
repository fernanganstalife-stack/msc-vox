#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class MSCVoxAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit MSCVoxAudioProcessorEditor(MSCVoxAudioProcessor&);
    ~MSCVoxAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    MSCVoxAudioProcessor& processor;
    juce::Image skin;
    juce::Slider input, drive, output;
    juce::ToggleButton bypass { "BYPASS" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> inputAttach, driveAttach, outputAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttach;
    void styleSlider(juce::Slider&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MSCVoxAudioProcessorEditor)
};
