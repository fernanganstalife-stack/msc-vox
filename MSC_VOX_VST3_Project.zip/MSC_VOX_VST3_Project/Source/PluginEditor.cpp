#include "PluginEditor.h"
#include "BinaryData.h"

MSCVoxAudioProcessorEditor::MSCVoxAudioProcessorEditor(MSCVoxAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    skin = juce::ImageCache::getFromMemory(BinaryData::msc_vox_skin_png, BinaryData::msc_vox_skin_pngSize);
    setSize(1536, 1024);

    styleSlider(input); styleSlider(drive); styleSlider(output);
    addAndMakeVisible(input); addAndMakeVisible(drive); addAndMakeVisible(output);
    addAndMakeVisible(bypass);
    inputAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.parameters, "input", input);
    driveAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.parameters, "drive", drive);
    outputAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.parameters, "output", output);
    bypassAttach = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(processor.parameters, "bypass", bypass);
}

void MSCVoxAudioProcessorEditor::styleSlider(juce::Slider& s)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 18);
    s.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffc044ff));
    s.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff17132c));
    s.setColour(juce::Slider::thumbColourId, juce::Colour(0xffe4d7ff));
    s.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    s.setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xee090b24));
    s.setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff7e39d8));
}

void MSCVoxAudioProcessorEditor::paint(juce::Graphics& g)
{
    if (skin.isValid()) g.drawImage(skin, getLocalBounds().toFloat());
    else { g.fillAll(juce::Colour(0xff080b20)); g.setColour(juce::Colours::white); g.drawFittedText("MSC VOX", getLocalBounds(), juce::Justification::centred, 1); }
}

void MSCVoxAudioProcessorEditor::resized()
{
    // Functional controls are placed over the corresponding controls in the supplied skin.
    input.setBounds(27, 700, 78, 105);
    drive.setBounds(145, 730, 88, 105);
    output.setBounds(1330, 700, 82, 105);
    bypass.setBounds(1240, 920, 120, 35);
}
