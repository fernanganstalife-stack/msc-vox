MSC VOX — proyecto inicial VST3 para Windows
=============================================

IMPORTANTE
- Este ZIP NO contiene todavía un .vst3 compilado.
- Contiene el código fuente y la imagen de interfaz que compartiste.
- Incluye un flujo de compilación en GitHub Actions para crear el VST3 en la nube.
- No necesitas instalar Visual Studio en tu PC. GitHub compila en una máquina Windows.
- Sí necesitas una cuenta de GitHub y conexión a internet para descargar JUCE durante la compilación.

QUÉ FUNCIONA EN ESTA PRIMERA VERSIÓN
- La interfaz usa tu imagen como fondo.
- Hay controles funcionales de Input, Drive y Output colocados sobre la imagen.
- Bypass.
- Procesamiento básico de saturación/distorsión.
- Guarda y recupera los parámetros.

QUÉ TODAVÍA NO ESTÁ IMPLEMENTADO
- Compresor, EQ, de-esser, reverb, delay, chorus, presets completos, medidores en tiempo real,
  animaciones de personajes y gestión visual de presets. Los textos y controles dibujados en la
  imagen son parte del fondo, no controles funcionales todavía.

CÓMO GENERAR EL VST3 SIN VISUAL STUDIO
1. Entra a https://github.com y crea una cuenta si no tienes.
2. Crea un repositorio nuevo llamado MSC-VOX.
3. Sube TODO el contenido de este ZIP al repositorio (incluida la carpeta .github).
4. Abre la pestaña Actions del repositorio.
5. Selecciona "Build MSC VOX VST3" y pulsa "Run workflow" (o espera a que termine el primer push).
6. Cuando termine en verde, abre esa ejecución y descarga el artefacto "MSC-VOX-VST3-Windows".
7. Descomprime el archivo. Copia "MSC VOX.vst3" a:
   C:\Program Files\Common Files\VST3
8. En FL Studio: Options > Manage plugins > Find installed plugins.

Si la compilación falla, comparte aquí el mensaje de error o una captura de la pestaña Actions.
